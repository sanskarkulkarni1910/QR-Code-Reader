// Select DOM elements
const scanButton = document.getElementById('scan-button');
const fileInput = document.getElementById('file-input');
const scannerContainer = document.getElementById('scanner-container');
const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const qrResult = document.getElementById('qr-result');

// QR Code scanner state
let scanning = false;
let videoStream = null;

// Start scanning when the user clicks the "Scan QR Code" button
scanButton.addEventListener('click', startScanning);

// Start scanning from the camera
function startScanning() {
  scannerContainer.style.display = 'block';
  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
      .then(stream => {
        videoStream = stream;
        video.srcObject = stream;
        video.play();
        scanning = true;
        video.onloadedmetadata = function () {
          // Ensure the video metadata is loaded, then set canvas dimensions and start scanning
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          requestAnimationFrame(scanQRCode); // Start the QR code scanning loop
        };
      })
      .catch(err => {
        qrResult.innerText = "Error accessing camera.";
        console.error(err);
      });
  } else {
    qrResult.innerText = "Camera access is not available.";
  }
}

// Scan the QR code from the camera feed
function scanQRCode() {
  if (!scanning) return;

  const context = canvas.getContext('2d');
  
  // Ensure the canvas size matches the video feed
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;

  // Draw the current frame from the video feed onto the canvas
  context.drawImage(video, 0, 0, canvas.width, canvas.height);
  
  const imageData = context.getImageData(0, 0, canvas.width, canvas.height);

  // Decode QR code
  const decoded = jsQR(imageData.data, canvas.width, canvas.height);

  if (decoded) {
    qrResult.innerText = `Decoded Content: ${decoded.data}`;
    scanning = false;
    videoStream.getTracks().forEach(track => track.stop()); // Stop the video stream after decoding
  } else {
    requestAnimationFrame(scanQRCode); // Keep scanning until QR is detected
  }
}
// Handle file input to upload an image and decode the QR code
fileInput.addEventListener('change', handleFileUpload);

function handleFileUpload(event) {
  const file = event.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = function (e) {
      const img = new Image();
      img.onload = function () {
        const context = canvas.getContext('2d');
        canvas.width = img.width;
        canvas.height = img.height;
        context.drawImage(img, 0, 0, img.width, img.height);
        const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
        const decoded = jsQR(imageData.data, canvas.width, canvas.height);

        if (decoded) {
          qrResult.innerText = `Decoded Content: ${decoded.data}`;
        } else {
          qrResult.innerText = 'Unable to decode the QR code.';
        }
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  }
}
